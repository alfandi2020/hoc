<footer>
	<div class="pull-right">
		projectmine - provide by. <a href="https://istefa.co.id">istefa &copy;2019</a>
	</div>
	<div class="clearfix"></div>
</footer>